﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float speed;
    Vector2 pos;
    public Manager check;


    // Start is called before the first frame update
    void Start()
    {
        pos = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void FixedUpdate()
    {
        pos.x += Input.GetAxis("Horizontal") * speed * Time.deltaTime;

        pos.x = Mathf.Clamp(pos.x, -2.2f, 2.2f);

        transform.position = pos;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "enemyBox")
        {
            Destroy(gameObject);
            check.GameOver();
        }

    }
}
