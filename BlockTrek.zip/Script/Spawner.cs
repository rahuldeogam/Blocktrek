﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class Spawner : MonoBehaviour
{
    public GameObject ebox;

    public float delayTimer = 1;
    float timer;

    // Start is called before the first frame update
    void Start()
    {
        timer = delayTimer;
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;

        if (timer <= 0)
        {
            Vector3 ipos = new Vector3(Random.Range(-2f, 2f), transform.position.y, transform.position.z);

            Instantiate(ebox, ipos, transform.rotation);

            timer = 1f;
        }

    }
}
