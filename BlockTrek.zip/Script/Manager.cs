﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Manager : MonoBehaviour
{
    public Text scoreText;
    int score;
    bool overGame;

    public Button btnRestart;
    Scene currentScene;

    // Start is called before the first frame update
    void Start()
    {
        currentScene = SceneManager.GetActiveScene();
        score = 0;
        overGame = false;
        InvokeRepeating("scoreIncrement", 1.0f, 1.0f);
    }

    // Update is called once per frame
    void Update()
    {
        if (currentScene.name == "Game")
        {
            if (!overGame)
            {
                scoreText.text = score.ToString();
            }
        }
      
   
    }

    // Start Button
    public void StartGame()
    {
        SceneManager.LoadScene("Game");
    }

    // Score Update
    public void scoreIncrement()
    {
        score += 1;
    }

    //Game Check Over
    public void GameOver()
    {
        overGame = true;
        btnRestart.gameObject.SetActive(true);
    }

    //Restart the Game
    public void RestartGame()
    {
        SceneManager.LoadScene("Game");
    }
}
